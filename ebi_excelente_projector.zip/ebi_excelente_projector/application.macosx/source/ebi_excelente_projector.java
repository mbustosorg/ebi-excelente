import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import de.bezier.data.sql.*; 
import java.util.Date; 
import java.util.Map; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ebi_excelente_projector extends PApplet {

/*

    Copyright (C) 2016 Mauricio Bustos (m@bustos.org)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/





MySQL msql;
int lastRefresh = millis();
boolean updatingEntries = false;

int textRows = 15;
int SlotCount = 10;
int textSpacing = 40;
int numBalls = 500;
float spring = 0.1f;
float gravity = 0.9f;
float friction = -0.3f;
ArrayList<Ball> balls = new ArrayList<Ball>();
ArrayList<EntryText> entryText = new ArrayList<EntryText>();
HashMap<Integer,MessageSize> textSizeMap = new HashMap<Integer,MessageSize>();
int lastIdSeen = 0;
int BoxBoundYup = -75;
int BoxBoundYdown = 50;
int BoxBoundXleft = -30;
int BoxBoundXright = 30;

int gold = color(232, 195, 0);
int green = color(0, 232, 87);
int[] ebiColors = { color(0, 195, 0), color(0, 0, 195), color(195, 195, 195) };
int[] tails = new int[textRows];

public void setup() {
  size(displayWidth, displayHeight);
  for (int i = 0; i < textRows; i++) {
    tails[i] = width;
  }
  noStroke();
  fill(255, 204);
     
  String user     = "ebiexcelente";
  String pass     = "tnnq656544gh";
  String database = "ebiexcelente";

  textSizeMap.put(20, new MessageSize(20));
  textSizeMap.put(50, new MessageSize(50));
  textSizeMap.put(100, new MessageSize(100));

  msql = new MySQL( this, "mysql.bustos.org", database, user, pass );
  updateEntries();  
}

public void updateEntries() {
  if ( msql.connect() )
  {
    msql.query( "SELECT * FROM Entry where id > " + str(lastIdSeen));
    if (!updatingEntries) {      
      updatingEntries = true;
      while (msql.next())
      {
        entryText.add(new EntryText(msql.getString("subject"), msql.getString("adjective"), msql.getString("language"), textSizeMap.get(msql.getInt("donation"))));
        lastIdSeen = max(lastIdSeen, msql.getInt("id"));
      }
      updatingEntries = false;
    }
  }
}

public void update() {
  for (EntryText text : entryText) {
    if (text.offScreen()) {
      println("Resetting " + text.subject + " : " + text.adjective);
      text.resetX();
    }
  }
  if (millis() % 10 == 0 && balls.size() < numBalls) {
    balls.add(new Ball(width / 2, 0.0f, random(-10.0f, 10.0f), random(2.0f, 3.0f), random(20, 30), balls.size() + 1, balls, entryText));
  }  
}

public void draw() {
  update();
  background(0);
  if (millis() > lastRefresh + 20000) {
    lastRefresh = millis();
    thread("updateEntries");
  }
  for (Ball ball : balls) {
    ball.collide();
    ball.move();
    ball.display();  
  }
  if (!updatingEntries) {
    updatingEntries = true;
    for (EntryText text : entryText) {
      text.update();
      text.display();
    }
    updatingEntries = false;
  }
}

class MessageSize {
  int englishHeaderWidth = 0;
  int spanishHeaderWidth = 0;
  int englishEbiIsWidth = 0;
  int spanishEbiIsWidth = 0;
  int englishEbiIsExWidth = 0;
  int spanishEbiIsExWidth = 0;
  int size = 0;
  int Xheight = 0;

  MessageSize(int sizeIn) {
    println(sizeIn);
    size = sizeIn;
    Xheight = size + size;
    textSize(size);
    englishEbiIsWidth = PApplet.parseInt(textWidth(" is e"));
    textSize(Xheight);
    englishHeaderWidth = englishEbiIsWidth + PApplet.parseInt(textWidth("X"));
    englishEbiIsExWidth = englishHeaderWidth;
    textSize(size);
    englishHeaderWidth += PApplet.parseInt(textWidth(" cellent because"));
    textSize(size);
    spanishEbiIsWidth = PApplet.parseInt(textWidth(" es e"));
    textSize(Xheight);
    spanishHeaderWidth = spanishEbiIsWidth + PApplet.parseInt(textWidth("X"));
    spanishEbiIsExWidth = spanishHeaderWidth;
    textSize(size);
    spanishHeaderWidth += PApplet.parseInt(textWidth(" celente porque"));
  }
  
  public int width(String language) {
    if (language.equals("english")) return englishHeaderWidth;
    else return spanishHeaderWidth;
  }
  
  public void drawMessage(String language, int x, int y, int currentColor) {
    if (language.equals("english")) {
      fill(currentColor);
      textSize(size);    
      text(" is e", x, y);
      textSize(Xheight);
      fill(gold);
      text("X", x + englishEbiIsWidth, y + size / 4);
      textSize(size);
      fill(currentColor);
      text("cellent because", x + englishEbiIsExWidth, y);
    } else {
      fill(currentColor);
      textSize(size);    
      text(" es e", x, y);
      textSize(Xheight);
      fill(gold);
      text("X", x + spanishEbiIsWidth, y + size / 4);
      textSize(size);
      fill(currentColor);
      text("celente porque", x + englishEbiIsExWidth, y);
    }
  }
}

class EntryText {

  String subject, adjective;
  int subjectWidth, adjectiveWidth, totalWidth;
  MessageSize messageSize;
  String language;
  int index;
  int x = 0;
  int y = 0;
  int currentColor;
  int row = 0;
  
  EntryText(String subjectIn, String adjectiveIn, String languageIn, MessageSize messageSizeIn) {
    subject = subjectIn;
    adjective = adjectiveIn;
    language = languageIn;
    messageSize = messageSizeIn;
    textSize(messageSize.size);
    subjectWidth = PApplet.parseInt(textWidth(subject));
    adjectiveWidth = PApplet.parseInt(textWidth(adjective));
    totalWidth = subjectWidth + messageSize.width(language) + adjectiveWidth;
    row = PApplet.parseInt(random(15) + 1) - 1;
    y = PApplet.parseInt((row + 1) / 15.0f * height);
    resetX();
  }
  
  public void resetX() {
    currentColor = ebiColors[PApplet.parseInt(random(3))];
    x = max(tails[row] + textSpacing, PApplet.parseInt(width + random(width)));
    tails[row] = x + PApplet.parseInt(totalWidth);
  }
  
  public void update() {
    x -= entryText.size() / 6;
  }

  public boolean offScreen() {
    return x <= -totalWidth;
  }
  
  public void display() {
    fill(50);
    //rect(x, y - 50, thisTextWidth + headerWidth, 75);
    textSize(messageSize.size);
    fill(currentColor);
    text(subject, x, y);
    messageSize.drawMessage(language, x + subjectWidth, y, currentColor);
    textSize(messageSize.size);
    fill(currentColor);
    text(adjective, x + subjectWidth + messageSize.width(language), y);
  }
  
}

class Ball {
  
  float x, y;
  float diameter;
  float vx = 0;
  float vy = 0;
  int id;
  ArrayList<Ball> others;
  ArrayList<EntryText> texts;
 
  Ball(float xin, float yin, float vxin, float vyin, float din, int idin, ArrayList<Ball> oin, ArrayList<EntryText> textsin) {
    x = xin;
    y = yin;
    vx = vxin;
    vy = vyin;
    diameter = din;
    id = idin;
    others = oin;
    texts = textsin;
    //vx = random(0.1) - 0.1;
    //vy = random(0.1) - 0.1;
  } 
  
  public void collide() {
    for (Ball other : others) {
      float dx = other.x - x;
      float dy = other.y - y;
      float distance = sqrt(dx*dx + dy*dy);
      float minDist = other.diameter/2 + diameter/2;
      if (distance < minDist) { 
        float angle = atan2(dy, dx);
        float targetX = x + cos(angle) * minDist;
        float targetY = y + sin(angle) * minDist;
        float ax = (targetX - other.x) * spring;
        float ay = (targetY - other.y) * spring;
        vx -= ax;
        vy -= ay;
        other.vx += ax;
        other.vy += ay;
      }
    }
  }
  
  public void move() {
    for (EntryText text : texts) {
      if (x > text.x + BoxBoundXleft && x < text.x + text.totalWidth + BoxBoundXright && 
          y > text.y + BoxBoundYup && y < text.y + BoxBoundYdown) {
        if (x < text.x) { x = text.x + BoxBoundXleft; vx = -vx; }
         else if (x > (text.x + text.totalWidth)) { x = text.x + text.totalWidth + BoxBoundXright; vx = -vx; }
        else if (y < text.y) { y = text.y + BoxBoundYup; vy = -vy;}
        else { y = text.y + BoxBoundYdown; vy = -vy; }
      } 
    }   
    vy += gravity;
    x += vx;
    y += vy;
    if (x + diameter/2 > width) {
      x = width - diameter/2;
      vx *= friction; 
    }
    else if (x - diameter/2 < 0) {
      x = diameter/2;
      vx *= friction;
    }
    if (y + diameter/2 > height) {
      y = height - diameter/2;
      vy *= friction; 
    } 
    else if (y - diameter/2 < 0) {
      y = diameter/2;
      vy *= friction;
    }
  }
  
  public void display() {
    fill(50);
    ellipse(x, y, diameter, diameter);
    stroke(150);
    //line(x, y, x - vx * 10, y - vy * 10);
    noStroke();
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--hide-stop", "ebi_excelente_projector" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
